package com.denis.denisblackbelt.services;

import com.denis.denisblackbelt.models.LoginUser;
import com.denis.denisblackbelt.models.User;
import com.denis.denisblackbelt.repositories.UserRepository;
import org.mindrot.jbcrypt.BCrypt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.BindingResult;

import java.util.Optional;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;

    public User register(User newUser, BindingResult result){

        Optional<User> potentialUser = userRepository.findByEmail(newUser.getEmail());

        if(potentialUser.isPresent()){
            result.rejectValue("email","EmailTaken",
                    "the email has already been taken");
        }
        if(!newUser.getPassword().equals(newUser.getConfirm())) {
            result.rejectValue("confirm", "Matches",
                    "The Confirm Password must match Password!");
        }
        if(result.hasErrors()){
            return null;
        }
        else{
            String hashed = BCrypt.hashpw(newUser.getPassword(), BCrypt.gensalt());
            newUser.setPassword(hashed);
            return userRepository.save(newUser);
        }
    }

    public User login(LoginUser newLoginObject, BindingResult result){

        Optional<User> potentialUser = userRepository.findByEmail(newLoginObject.getEmail());

        if(!potentialUser.isPresent()){
            result.rejectValue("email","EmailNotFound","the email does not exist");
        }else{
            if(!BCrypt.checkpw(newLoginObject.getPassword(), potentialUser.get().getPassword())) {
                result.rejectValue("password", "Matches", "Invalid Password!");
            }
        }
        if(result.hasErrors()){
            return null;
        }else{
            return potentialUser.get();
        }
    }

    public User findUser(Long id){
        Optional<User> optionalUser = userRepository.findById(id);

        if(!optionalUser.isPresent()){
            return null;
        }
        else{
            return optionalUser.get();
        }
    }

    public void saveUser(User user){
        userRepository.save(user);
    }

    public void deleteUser(User user){
        userRepository.delete(user);
    }
}
