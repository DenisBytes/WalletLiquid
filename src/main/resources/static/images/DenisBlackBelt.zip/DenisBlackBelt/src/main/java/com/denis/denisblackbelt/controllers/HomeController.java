package com.denis.denisblackbelt.controllers;

import com.denis.denisblackbelt.models.LoginUser;
import com.denis.denisblackbelt.models.Table;
import com.denis.denisblackbelt.models.User;
import com.denis.denisblackbelt.services.TableService;
import com.denis.denisblackbelt.services.UserService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
public class HomeController {

    @Autowired
    private UserService userService;

    @Autowired
    private TableService tableService;

    //INDEX PAGE
    @GetMapping("/")
    public String index(@ModelAttribute("newUser") User user,
                        @ModelAttribute("newLogin") LoginUser loginUser,
                        HttpSession session){
        session.setAttribute("loggedInUserID", null);
        return"index";
    }

    //REGISTERING THE USER
    @PostMapping("/register")
    public String registerIndex(@Valid @ModelAttribute("newUser")User user,
                                BindingResult result, Model model, HttpSession session){
        userService.register(user,result);

        if(result.hasErrors()){
            model.addAttribute("newLogin", new LoginUser());
            return "index";
        }
        session.setAttribute("loggedInUserID", user.getId());

        return "redirect:/home";
    }

    //LOGGING IN THE USER
    @PostMapping("/login")
    public String loginIndex(@Valid @ModelAttribute("newLogin") LoginUser loginUser,
                             BindingResult result, Model model, HttpSession session){
        User user = userService.login(loginUser,result);

        if(result.hasErrors()){
            model.addAttribute("newUser",new User());
            return "index";
        }

        session.setAttribute("loggedInUserID", user.getId());

        return "redirect:/home";
    }




    //GET MAPPINGS
    @GetMapping("/home")
    public String home(Model model, HttpSession session){
        if(session.getAttribute("loggedInUserID") == null){
            return "redirect:/";
        }
        User user = userService.findUser((Long) session.getAttribute("loggedInUserID"));
        model.addAttribute("user",user);
        model.addAttribute("tables",tableService.allOrderedTablesbyUser(user));

        return "home";
    }

    @GetMapping("/tables/new")
    public String newTableIndex(@ModelAttribute("newTable")Table table, HttpSession session){
        if(session.getAttribute("loggedInUserID") == null){
            return "redirect:/";
        }
        return "newtable";
    }

    @GetMapping("/tables")
    public String allTablesIndex(Model model,HttpSession session){
        if(session.getAttribute("loggedInUserID") == null){
            return "redirect:/";
        }

        model.addAttribute("allTables", tableService.allUnassignedTables());
        return "alltables";
    }

    @GetMapping("/tables/{tableId}/edit")
    public String editTableIndex(@PathVariable(name = "tableId")Long tableId,
                                 Model model, HttpSession session){
        if(session.getAttribute("loggedInUserID") == null){
            return "redirect:/";
        }
        model.addAttribute("table", tableService.findTableBYId(tableId));
        return "edittable";
    }







    //POST MAPPINGS
    @PostMapping("/tables/new")
    public String newTable(@Valid @ModelAttribute("newTable") Table table,
                           BindingResult result, HttpSession session){
        if(result.hasErrors()){
            return "newtable";
        }
        User user = userService.findUser((Long) session.getAttribute("loggedInUserID"));
        table.setUser(user);
        tableService.saveTable(table);

        return "redirect:/home";
    }

    @PutMapping("/tables/{tableId}/edit")
    public String editTable(@Valid @ModelAttribute("table")Table table,
                            @PathVariable(name = "tableId")Long tableId,
                            BindingResult result, HttpSession session){
        if (result.hasErrors()){
            return "edittable";
        }
        table.setId(tableId);
        table.setUser(userService.findUser((Long) session.getAttribute("loggedInUserID")));
        tableService.saveTable(table);
        return "redirect:/home";
    }








    //"POST METHODS" BUT WITH GET MAPPING
    @GetMapping("/delete/{tableId}")
    public String deletTable(@PathVariable(name = "tableId")Long tableId){
        Table table = tableService.findTableBYId(tableId);

        tableService.deleteTable(table);
        return "redirect:/home";
    }

    @GetMapping("/giveup/{tableId}")
    public String giveUpTable(@PathVariable(name = "tableId")Long tableId){
        Table table = tableService.findTableBYId(tableId);

        table.setUser(null);
        tableService.saveTable(table);
        return "redirect:/home";
    }

    @GetMapping("/pickup/{tableId}")
    public String pickUpTable(@PathVariable(name = "tableId")Long tableId, HttpSession session){
        Table table = tableService.findTableBYId(tableId);

        table.setUser(userService.findUser((Long) session.getAttribute("loggedInUserID")));
        tableService.saveTable(table);
        return "redirect:/home";
    }
}
