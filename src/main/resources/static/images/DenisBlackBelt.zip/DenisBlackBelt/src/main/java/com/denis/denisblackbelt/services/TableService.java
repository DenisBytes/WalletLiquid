package com.denis.denisblackbelt.services;

import com.denis.denisblackbelt.models.Table;
import com.denis.denisblackbelt.models.User;
import com.denis.denisblackbelt.repositories.TableRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TableService {
    @Autowired
    private TableRepository tableRepository;

    public List<Table> allTables(){
        return tableRepository.findAll();
    }

    public void saveTable(Table table){
        tableRepository.save(table);
    }

    public List<Table> allUnassignedTables(){
        return tableRepository.findByUserIsNull();
    }

    public Table findTableBYId(Long id){
        Optional<Table> optionalTable = tableRepository.findById(id);

        if (optionalTable.isEmpty()){
            return null;
        }

        else{
            return optionalTable.get();
        }
    }

    public void deleteTable(Table table){
        tableRepository.delete(table);
    }

    public List<Table> allOrderedTablesbyUser(User user) {
        return tableRepository.findAllByUserOrderByCreatedAtDesc(user);
    }
}
