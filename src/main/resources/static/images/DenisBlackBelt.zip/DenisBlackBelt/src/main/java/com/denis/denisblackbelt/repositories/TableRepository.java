package com.denis.denisblackbelt.repositories;

import com.denis.denisblackbelt.models.Table;
import com.denis.denisblackbelt.models.User;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface TableRepository extends CrudRepository<Table, Long> {
    List<Table> findAll();

    List<Table> findByUserIsNull();

    Optional<Table> findById(Long id);

    List<Table> findAllByUserOrderByCreatedAtDesc(User user);
}
